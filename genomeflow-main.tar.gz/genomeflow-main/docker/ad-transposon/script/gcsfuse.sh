#!/bin/bash
gcsfuse --key-file /root/keys/project.key.json ad_transposon /bucket
