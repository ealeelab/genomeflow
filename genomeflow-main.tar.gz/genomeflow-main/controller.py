#!/usr/bin/env python
# controller for task handling

# Check DAG

# Check Next Step of the DAG

# if current step is done, execute next step
# if next step is not available, stop there