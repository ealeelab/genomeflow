# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


from synapseDownloader import SynapseDownloader


# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    # Check input configuration file

    print('Start genomeFlow')

    # Currently only support

    # Check download disk size from access sample size (GB)

    # Check result disk size from sample size (estimated from input sample size)

    # SynapeDownloader Selected


    # Initialize synapeDownloader
    print('access to synapse downloader')
    synapeDownloader = SynapseDownloader('nuggiowl','chlwowns')

    print('download sampleFile')
    synapeDownloader.downloadSample('syn1906479')




# See PyCharm help at https://www.jetbrains.com/help/pycharm/
